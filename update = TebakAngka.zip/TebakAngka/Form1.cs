using System;
using System.Windows.Forms;

namespace MyWinFormsApp
{
    public partial class Form1 : Form
    {
        private Random random = new Random();
        private int angkaRahasia;
        private int percobaan;
        private string mode;

        public Form1()
        {
            InitializeComponent();
            ResetGame();
        }

        private void ResetGame()
        {
            mode = "";
            angkaRahasia = 0;
            percobaan = 0;
            comboBoxMode.SelectedIndex = 0;
            labelInfo.Text = "Pilih mode dan mulai permainan.";
            textBoxTebakan.Clear();
        }

        private void buttonMulai_Click(object sender, EventArgs e)
        {
            if (comboBoxMode.SelectedItem == null)
            {
                MessageBox.Show("Pilih mode terlebih dahulu!");
                return;
            }

            mode = comboBoxMode.SelectedItem.ToString();

            switch (mode)
            {
                case "Easy":
                    angkaRahasia = random.Next(1, 11);
                    percobaan = int.MaxValue;
                    labelInfo.Text = "Easy Mode: Tebak angka antara 1-10";
                    break;
                case "Normal":
                    angkaRahasia = random.Next(1, 101);
                    percobaan = 25;
                    labelInfo.Text = "Normal Mode: Tebak angka antara 1-100";
                    break;
                case "Hard":
                    angkaRahasia = random.Next(1, 1001);
                    percobaan = 15;
                    labelInfo.Text = "Hard Mode: Tebak angka antara 1-1000";
                    break;
            }

            textBoxTebakan.Enabled = true;
            buttonTebak.Enabled = true;
            textBoxTebakan.Focus();
        }

        private void buttonTebak_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBoxTebakan.Text, out int tebakan))
            {
                percobaan--;

                if (tebakan < angkaRahasia)
                    labelInfo.Text = $"Terlalu kecil! Sisa percobaan: {percobaan}";
                else if (tebakan > angkaRahasia)
                    labelInfo.Text = $"Terlalu besar! Sisa percobaan: {percobaan}";
                else
                {
                    MessageBox.Show($"Selamat! Anda berhasil menebak angka {angkaRahasia}", "Menang");
                    ResetGame();
                    return;
                }

                if (percobaan <= 0 && mode != "Easy")
                {
                    MessageBox.Show("Kesempatan habis! Anda kalah.", "Game Over");
                    ResetGame();
                }
            }
            else
            {
                MessageBox.Show("Masukkan angka yang valid!", "Error");
            }

            textBoxTebakan.Clear();
            textBoxTebakan.Focus();
        }
    }
}

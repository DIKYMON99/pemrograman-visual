﻿namespace MyWinFormsApp
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.comboBoxMode = new System.Windows.Forms.ComboBox();
            this.buttonMulai = new System.Windows.Forms.Button();
            this.textBoxTebakan = new System.Windows.Forms.TextBox();
            this.buttonTebak = new System.Windows.Forms.Button();
            this.labelInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();

            // comboBoxMode
            this.comboBoxMode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxMode.FormattingEnabled = true;
            this.comboBoxMode.Items.AddRange(new object[] {
            "Easy",
            "Normal",
            "Hard"});
            this.comboBoxMode.Location = new System.Drawing.Point(30, 30);
            this.comboBoxMode.Name = "comboBoxMode";
            this.comboBoxMode.Size = new System.Drawing.Size(150, 24);

            // buttonMulai
            this.buttonMulai.Location = new System.Drawing.Point(200, 30);
            this.buttonMulai.Name = "buttonMulai";
            this.buttonMulai.Size = new System.Drawing.Size(75, 25);
            this.buttonMulai.Text = "Mulai";
            this.buttonMulai.UseVisualStyleBackColor = true;
            this.buttonMulai.Click += new System.EventHandler(this.buttonMulai_Click);

            // textBoxTebakan
            this.textBoxTebakan.Location = new System.Drawing.Point(30, 80);
            this.textBoxTebakan.Name = "textBoxTebakan";
            this.textBoxTebakan.Size = new System.Drawing.Size(150, 22);
            this.textBoxTebakan.Enabled = false;

            // buttonTebak
            this.buttonTebak.Location = new System.Drawing.Point(200, 78);
            this.buttonTebak.Name = "buttonTebak";
            this.buttonTebak.Size = new System.Drawing.Size(75, 25);
            this.buttonTebak.Text = "Tebak";
            this.buttonTebak.UseVisualStyleBackColor = true;
            this.buttonTebak.Enabled = false;
            this.buttonTebak.Click += new System.EventHandler(this.buttonTebak_Click);

            // labelInfo
            this.labelInfo.AutoSize = true;
            this.labelInfo.Location = new System.Drawing.Point(30, 130);
            this.labelInfo.Name = "labelInfo";
            this.labelInfo.Size = new System.Drawing.Size(260, 17);
            this.labelInfo.Text = "Pilih mode dan mulai permainan.";

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(340, 180);
            this.Controls.Add(this.comboBoxMode);
            this.Controls.Add(this.buttonMulai);
            this.Controls.Add(this.textBoxTebakan);
            this.Controls.Add(this.buttonTebak);
            this.Controls.Add(this.labelInfo);
            this.Name = "Form1";
            this.Text = "Game Tebak Angka";
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.ComboBox comboBoxMode;
        private System.Windows.Forms.Button buttonMulai;
        private System.Windows.Forms.TextBox textBoxTebakan;
        private System.Windows.Forms.Button buttonTebak;
        private System.Windows.Forms.Label labelInfo;
    }
}
